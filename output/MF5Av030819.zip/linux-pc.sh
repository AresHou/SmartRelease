#!/bin/sh
cd linuxflash
./linuxflash-pc.sh
cd ..
