#!/bin/sh
cd linuxflash
./linuxflash.sh
cd ..
